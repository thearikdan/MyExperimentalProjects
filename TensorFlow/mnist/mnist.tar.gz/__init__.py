import input_data
import mnist

